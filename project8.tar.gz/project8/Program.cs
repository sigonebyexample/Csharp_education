﻿Random dice = new Random();
int roll = dice.Next(1, 7);
Console.WriteLine($"You rolled a {roll}!");