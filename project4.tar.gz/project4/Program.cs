﻿string LOM = "3";
string name= "Bob";
string clac= "34.3";
string message="Hello, "+name+"! You have "+LOM+" messages in your inbox. The temperature is "+clac+" celsius.";
Console.WriteLine(message);
