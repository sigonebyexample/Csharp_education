﻿Console.WriteLine("123");
Console.WriteLine(12.111111111111111111111);
Console.WriteLine(12.111111111111111111111F);
Console.WriteLine(12.111111111111111111111M);
Console.WriteLine(12.111111111111111111111m);
Console.WriteLine("true");
Console.WriteLine(true);
