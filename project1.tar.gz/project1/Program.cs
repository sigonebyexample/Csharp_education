﻿using System;
Console.WriteLine("Write down your name: ");
string name = Console.ReadLine();
name = name + ", Welcome to C#.";
Console.WriteLine(name);
