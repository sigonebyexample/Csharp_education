﻿Console.WriteLine('H');
Console.WriteLine('E');
Console.WriteLine('L');
Console.WriteLine('L');
Console.WriteLine('O');
